GeoIP Legacy data sets go here.
